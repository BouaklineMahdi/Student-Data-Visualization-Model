import type { Student } from "@/components/data-analyzer"

export function addAverageGrade(students: Student[]): Student[] {
  return students.map((student) => {
    const g1 = typeof student.G1 === "number" ? student.G1 : 0
    const g2 = typeof student.G2 === "number" ? student.G2 : 0
    const g3 = typeof student.G3 === "number" ? student.G3 : 0
    const avg = Number.parseFloat(((g1 + g2 + g3) / 3).toFixed(2))

    return {
      ...student,
      G_Avg: avg,
    }
  })
}

export function getSampleData(): Student[] {
  // Sample data that simulates what would be loaded from the CSV file
  const sampleData: Student[] = [
    { School: "GP", Age: 18, StudyTime: 2, Failures: 0, Health: 3, Absences: 6, G1: 5, G2: 6, G3: 6 },
    { School: "GP", Age: 17, StudyTime: 2, Failures: 0, Health: 3, Absences: 4, G1: 5, G2: 5, G3: 6 },
    { School: "GP", Age: 15, StudyTime: 2, Failures: 3, Health: 3, Absences: 10, G1: 7, G2: 8, G3: 10 },
    { School: "MS", Age: 18, StudyTime: 3, Failures: 0, Health: 5, Absences: 2, G1: 9, G2: 8, G3: 8 },
    { School: "MS", Age: 17, StudyTime: 3, Failures: 0, Health: 4, Absences: 4, G1: 14, G2: 14, G3: 14 },
    { School: "MS", Age: 17, StudyTime: 1, Failures: 0, Health: 4, Absences: 8, G1: 11, G2: 10, G3: 10 },
    { School: "MS", Age: 17, StudyTime: 3, Failures: 0, Health: 1, Absences: 7, G1: 10, G2: 9, G3: 9 },
    { School: "CF", Age: 15, StudyTime: 5, Failures: 2, Health: 3, Absences: 6, G1: 5, G2: 9, G3: 7 },
    { School: "BD", Age: 18, StudyTime: 3, Failures: 0, Health: 3, Absences: 1, G1: 13, G2: 12, G3: 12 },
    { School: "GP", Age: 16, StudyTime: 2, Failures: 1, Health: 5, Absences: 4, G1: 10, G2: 12, G3: 12 },
    { School: "MS", Age: 15, StudyTime: 1, Failures: 0, Health: 5, Absences: 0, G1: 14, G2: 15, G3: 15 },
    { School: "CF", Age: 17, StudyTime: 1, Failures: 2, Health: 5, Absences: 0, G1: 7, G2: 6, G3: 0 },
    { School: "BD", Age: 16, StudyTime: 2, Failures: 0, Health: 5, Absences: 6, G1: 13, G2: 14, G3: 14 },
    { School: "GP", Age: 16, StudyTime: 1, Failures: 0, Health: 5, Absences: 0, G1: 8, G2: 10, G3: 10 },
    { School: "MS", Age: 15, StudyTime: 2, Failures: 0, Health: 5, Absences: 0, G1: 13, G2: 14, G3: 14 },
  ]

  // Add average grade to each student
  const dataWithAvg = addAverageGrade(sampleData)
  console.log("Generated sample data:", dataWithAvg)
  return dataWithAvg
}
