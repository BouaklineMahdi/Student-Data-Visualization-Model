import { DataAnalyzer } from "@/components/data-analyzer"
import { ThemeProvider } from "@/components/theme-provider"

export default function Home() {
  return (
    <ThemeProvider>
      <main className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 py-8">
          <h1 className="mb-8 text-center text-4xl font-bold tracking-tight text-gray-900 dark:text-white">
            Student Data Analyzer
          </h1>
          <DataAnalyzer />
        </div>
      </main>
    </ThemeProvider>
  )
}
