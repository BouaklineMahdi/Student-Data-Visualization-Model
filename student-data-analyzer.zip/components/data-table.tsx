"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import type { Student } from "@/components/data-analyzer"

interface DataTableProps {
  data: Student[]
}

export function DataTable({ data }: DataTableProps) {
  const [page, setPage] = useState(1)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [searchTerm, setSearchTerm] = useState("")
  const [displayData, setDisplayData] = useState<Student[]>([])

  useEffect(() => {
    // Log the data to verify it's being passed correctly
    console.log("Data received in DataTable:", data)
    setDisplayData(data)
  }, [data])

  // Make sure we have data to display
  if (!data || data.length === 0) {
    return (
      <div className="rounded-md border p-8 text-center">
        <p className="text-gray-500">No data available to display.</p>
      </div>
    )
  }

  const filteredData = data.filter((student) => {
    return Object.values(student).some(
      (value) =>
        value !== null && value !== undefined && value.toString().toLowerCase().includes(searchTerm.toLowerCase()),
    )
  })

  const totalPages = Math.ceil(filteredData.length / rowsPerPage)
  const startIndex = (page - 1) * rowsPerPage
  const paginatedData = filteredData.slice(startIndex, startIndex + rowsPerPage)

  // Get column names from the first data item
  const columns = Object.keys(data[0]).filter((key) => key !== "id")

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Student Data ({data.length} records)</h3>
        <Input
          placeholder="Search..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-xs"
        />
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map((column) => (
                <TableHead key={column} className="font-bold">
                  {column === "G_Avg" ? "Grade Avg" : column === "StudyTime" ? "Study Time" : column}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedData.length > 0 ? (
              paginatedData.map((student, index) => (
                <TableRow key={index} className="hover:bg-gray-100 dark:hover:bg-gray-800">
                  {columns.map((column) => (
                    <TableCell key={column} className="text-black dark:text-white">
                      {student[column] !== undefined && student[column] !== null
                        ? column === "G_Avg"
                          ? typeof student[column] === "number"
                            ? student[column].toFixed(2)
                            : student[column]
                          : student[column].toString()
                        : "-"}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  No results found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            Showing {startIndex + 1}-{Math.min(startIndex + rowsPerPage, filteredData.length)} of {filteredData.length}{" "}
            results
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              Previous
            </Button>
            <span className="text-sm">
              Page {page} of {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
