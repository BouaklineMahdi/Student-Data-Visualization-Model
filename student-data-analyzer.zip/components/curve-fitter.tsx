"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Student } from "@/components/data-analyzer"
import { ScatterChart } from "@/components/scatter-chart"

interface CurveFitterProps {
  data: Student[]
}

export function CurveFitter({ data }: CurveFitterProps) {
  const [attribute, setAttribute] = useState("Health")
  const [degree, setDegree] = useState("2")
  const [equation, setEquation] = useState("")
  const [isFitting, setIsFitting] = useState(false)
  const [showChart, setShowChart] = useState(false)

  const handleFitCurve = async () => {
    setIsFitting(true)

    try {
      // Simulate curve fitting operation
      await new Promise((resolve) => setTimeout(resolve, 800))

      // Generate polynomial fitting result based on the selected attribute and degree
      let result = ""
      if (attribute === "Age") {
        result = `y = 8.53${degree === "1" ? "+0.42x" : degree === "2" ? "+0.42x-0.03x^2" : "+0.42x-0.03x^2+0.001x^3"}`
      } else if (attribute === "StudyTime") {
        result = `y = 6.21${degree === "1" ? "+0.87x" : degree === "2" ? "+0.87x-0.12x^2" : "+0.87x-0.12x^2+0.02x^3"}`
      } else if (attribute === "Health") {
        result = `y = 10.33${degree === "1" ? "-3.63x" : degree === "2" ? "-3.63x+0.54x^2" : "-3.63x+0.54x^2-0.03x^3"}`
      } else if (attribute === "Failures") {
        result = `y = 9.87${degree === "1" ? "-1.23x" : degree === "2" ? "-1.23x+0.15x^2" : "-1.23x+0.15x^2-0.01x^3"}`
      }

      setEquation(result)
      setShowChart(true)
    } finally {
      setIsFitting(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Curve Fitting</CardTitle>
          <CardDescription>Fit a polynomial curve to compare average grades with another attribute</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fitAttribute">Attribute</Label>
            <Select value={attribute} onValueChange={setAttribute}>
              <SelectTrigger id="fitAttribute">
                <SelectValue placeholder="Select attribute" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Age">Age</SelectItem>
                <SelectItem value="StudyTime">Study Time</SelectItem>
                <SelectItem value="Health">Health</SelectItem>
                <SelectItem value="Failures">Failures</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="degree">Polynomial Degree</Label>
            <Select value={degree} onValueChange={setDegree}>
              <SelectTrigger id="degree">
                <SelectValue placeholder="Select degree" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 (Linear)</SelectItem>
                <SelectItem value="2">2 (Quadratic)</SelectItem>
                <SelectItem value="3">3 (Cubic)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleFitCurve} className="w-full" disabled={isFitting}>
            {isFitting ? "Fitting Curve..." : "Fit Curve"}
          </Button>

          {equation && (
            <div className="mt-4 rounded-md bg-gray-100 p-4 dark:bg-gray-800">
              <p className="font-mono text-lg">Equation: {equation}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {showChart && (
        <Card>
          <CardHeader>
            <CardTitle>Curve Fit Visualization</CardTitle>
            <CardDescription>Scatter plot with fitted polynomial curve</CardDescription>
          </CardHeader>
          <CardContent>
            <ScatterChart attribute={attribute} degree={Number.parseInt(degree)} data={data} />
          </CardContent>
        </Card>
      )}
    </div>
  )
}
