"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { Student } from "@/components/data-analyzer"
import { addAverageGrade } from "@/lib/data-utils"

interface DataLoaderProps {
  onDataLoaded: (data: Student[]) => void
  onError: (message: string) => void
}

export function DataLoader({ onDataLoaded, onError }: DataLoaderProps) {
  const [fileName, setFileName] = useState("")
  const [attribute, setAttribute] = useState("")
  const [value, setValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleLoadData = async () => {
    if (!fileName) {
      onError("Please enter a file name")
      return
    }

    if (!attribute) {
      onError("Please select an attribute")
      return
    }

    setIsLoading(true)

    try {
      // In a real application, this would call your backend API
      // For demo purposes, we'll simulate loading data
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate data loading with sample data
      const sampleData: Student[] = [
        { School: "GP", Age: 18, StudyTime: 2, Failures: 0, Health: 3, Absences: 6, G1: 5, G2: 6, G3: 6 },
        { School: "GP", Age: 17, StudyTime: 2, Failures: 0, Health: 3, Absences: 4, G1: 5, G2: 5, G3: 6 },
        { School: "GP", Age: 15, StudyTime: 2, Failures: 3, Health: 3, Absences: 10, G1: 7, G2: 8, G3: 10 },
        { School: "MS", Age: 18, StudyTime: 3, Failures: 0, Health: 5, Absences: 2, G1: 9, G2: 8, G3: 8 },
        { School: "MS", Age: 17, StudyTime: 3, Failures: 0, Health: 4, Absences: 4, G1: 14, G2: 14, G3: 14 },
        { School: "MS", Age: 17, StudyTime: 1, Failures: 0, Health: 4, Absences: 8, G1: 11, G2: 10, G3: 10 },
        { School: "MS", Age: 17, StudyTime: 3, Failures: 0, Health: 1, Absences: 7, G1: 10, G2: 9, G3: 9 },
        { School: "CF", Age: 15, StudyTime: 5, Failures: 2, Health: 3, Absences: 6, G1: 5, G2: 9, G3: 7 },
        { School: "BD", Age: 18, StudyTime: 3, Failures: 0, Health: 3, Absences: 1, G1: 13, G2: 12, G3: 12 },
      ]

      // Filter data based on attribute and value if provided
      let filteredData = sampleData
      if (attribute && value) {
        filteredData = sampleData.filter((student) => {
          if (attribute === "School") {
            return student.School === value
          } else if (attribute === "Age") {
            return student.Age === Number.parseInt(value)
          } else if (attribute === "Health") {
            return student.Health === Number.parseInt(value)
          } else if (attribute === "Failures") {
            return student.Failures === Number.parseInt(value)
          }
          return true
        })
      }

      // Add average grade
      const dataWithAvg = addAverageGrade(filteredData)

      onDataLoaded(dataWithAvg)
    } catch (error) {
      onError("Failed to load data. Please check the file name and try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Load Student Data</CardTitle>
        <CardDescription>Enter file details and filter criteria to load student data</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="fileName">File Name</Label>
          <Input
            id="fileName"
            placeholder="student-mat.csv"
            value={fileName}
            onChange={(e) => setFileName(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="attribute">Filter Attribute</Label>
          <Select value={attribute} onValueChange={setAttribute}>
            <SelectTrigger id="attribute">
              <SelectValue placeholder="Select attribute" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All</SelectItem>
              <SelectItem value="School">School</SelectItem>
              <SelectItem value="Age">Age</SelectItem>
              <SelectItem value="Health">Health</SelectItem>
              <SelectItem value="Failures">Failures</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {attribute && attribute !== "All" && (
          <div className="space-y-2">
            <Label htmlFor="value">Attribute Value</Label>
            {attribute === "School" ? (
              <Select value={value} onValueChange={setValue}>
                <SelectTrigger id="value">
                  <SelectValue placeholder="Select school" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="GP">GP</SelectItem>
                  <SelectItem value="MS">MS</SelectItem>
                  <SelectItem value="CF">CF</SelectItem>
                  <SelectItem value="BD">BD</SelectItem>
                </SelectContent>
              </Select>
            ) : (
              <Input
                id="value"
                placeholder="Enter value"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                type={attribute === "School" ? "text" : "number"}
              />
            )}
          </div>
        )}

        <Button onClick={handleLoadData} className="w-full" disabled={isLoading}>
          {isLoading ? "Loading..." : "Load Data"}
        </Button>
      </CardContent>
    </Card>
  )
}
