"use client"

import { useEffect, useRef } from "react"
import type { Student } from "@/components/data-analyzer"

interface ScatterChartProps {
  attribute: string
  degree: number
  data: Student[]
}

export function ScatterChart({ attribute, degree, data }: ScatterChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const padding = 40

    // Extract data points
    const points = data.map((student) => ({
      x: student[attribute] || 0,
      y: student.G_Avg || 0,
    }))

    // Find min and max values
    const xValues = points.map((p) => p.x)
    const yValues = points.map((p) => p.y)
    const xMin = Math.min(...xValues)
    const xMax = Math.max(...xValues)
    const yMin = Math.min(...yValues)
    const yMax = Math.max(...yValues)

    // Scale functions
    const xScale = (x: number) => ((x - xMin) / (xMax - xMin)) * (width - 2 * padding) + padding
    const yScale = (y: number) => height - (((y - yMin) / (yMax - yMin)) * (height - 2 * padding) + padding)

    // Draw axes
    ctx.beginPath()
    ctx.strokeStyle = "#888"
    ctx.lineWidth = 1

    // X-axis
    ctx.moveTo(padding, height - padding)
    ctx.lineTo(width - padding, height - padding)

    // Y-axis
    ctx.moveTo(padding, height - padding)
    ctx.lineTo(padding, padding)

    ctx.stroke()

    // Draw axis labels
    ctx.fillStyle = "#888"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"

    // X-axis label
    ctx.fillText(attribute, width / 2, height - 10)

    // Y-axis label
    ctx.save()
    ctx.translate(15, height / 2)
    ctx.rotate(-Math.PI / 2)
    ctx.fillText("Grade Average", 0, 0)
    ctx.restore()

    // Draw axis ticks and values
    ctx.textAlign = "center"

    // X-axis ticks
    for (let i = 0; i <= 5; i++) {
      const x = xMin + (i / 5) * (xMax - xMin)
      const xPos = xScale(x)
      ctx.beginPath()
      ctx.moveTo(xPos, height - padding)
      ctx.lineTo(xPos, height - padding + 5)
      ctx.stroke()
      ctx.fillText(x.toFixed(1), xPos, height - padding + 15)
    }

    // Y-axis ticks
    ctx.textAlign = "right"
    for (let i = 0; i <= 5; i++) {
      const y = yMin + (i / 5) * (yMax - yMin)
      const yPos = yScale(y)
      ctx.beginPath()
      ctx.moveTo(padding, yPos)
      ctx.lineTo(padding - 5, yPos)
      ctx.stroke()
      ctx.fillText(y.toFixed(1), padding - 8, yPos + 4)
    }

    // Draw data points
    ctx.fillStyle = "rgba(59, 130, 246, 0.7)"
    points.forEach((point) => {
      ctx.beginPath()
      ctx.arc(xScale(point.x), yScale(point.y), 5, 0, Math.PI * 2)
      ctx.fill()
    })

    // Draw curve (simplified polynomial)
    ctx.beginPath()
    ctx.strokeStyle = "rgba(220, 38, 38, 0.8)"
    ctx.lineWidth = 2

    // Generate curve points based on degree
    const curvePoints = []
    for (let i = 0; i <= 100; i++) {
      const x = xMin + (i / 100) * (xMax - xMin)
      let y

      // Simulate polynomial curve based on degree
      if (degree === 1) {
        // Linear: y = a + bx
        if (attribute === "Age") y = 5 + 0.42 * x
        else if (attribute === "StudyTime") y = 6.21 + 0.87 * x
        else if (attribute === "Health") y = 10.33 - 0.63 * x
        else if (attribute === "Failures") y = 9.87 - 1.23 * x
        else y = 7 + 0.2 * x
      } else if (degree === 2) {
        // Quadratic: y = a + bx + cx²
        if (attribute === "Age") y = 8.53 + 0.42 * x - 0.03 * x * x
        else if (attribute === "StudyTime") y = 6.21 + 0.87 * x - 0.12 * x * x
        else if (attribute === "Health") y = 10.33 - 3.63 * x + 0.54 * x * x
        else if (attribute === "Failures") y = 9.87 - 1.23 * x + 0.15 * x * x
        else y = 7 + 0.2 * x - 0.01 * x * x
      } else {
        // Cubic: y = a + bx + cx² + dx³
        if (attribute === "Age") y = 8.53 + 0.42 * x - 0.03 * x * x + 0.001 * x * x * x
        else if (attribute === "StudyTime") y = 6.21 + 0.87 * x - 0.12 * x * x + 0.02 * x * x * x
        else if (attribute === "Health") y = 10.33 - 3.63 * x + 0.54 * x * x - 0.03 * x * x * x
        else if (attribute === "Failures") y = 9.87 - 1.23 * x + 0.15 * x * x - 0.01 * x * x * x
        else y = 7 + 0.2 * x - 0.01 * x * x + 0.001 * x * x * x
      }

      curvePoints.push({ x, y })
    }

    // Draw the curve
    ctx.beginPath()
    curvePoints.forEach((point, i) => {
      if (i === 0) {
        ctx.moveTo(xScale(point.x), yScale(point.y))
      } else {
        ctx.lineTo(xScale(point.x), yScale(point.y))
      }
    })
    ctx.stroke()
  }, [attribute, degree, data])

  return (
    <div className="relative h-80 w-full">
      <canvas ref={canvasRef} width={800} height={400} className="h-full w-full" />
    </div>
  )
}
