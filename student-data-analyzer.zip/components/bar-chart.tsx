"use client"

import { useEffect, useRef } from "react"
import type { Student } from "@/components/data-analyzer"

interface BarChartProps {
  attribute: string
  data: Student[]
}

export function BarChart({ attribute, data }: BarChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const padding = 60

    // Process data for histogram
    let categories: (string | number)[] = []
    let counts: number[] = []

    if (attribute === "School") {
      // For categorical data like School
      const schoolCounts: Record<string, number> = {}
      data.forEach((student) => {
        const school = student.School || "Unknown"
        schoolCounts[school] = (schoolCounts[school] || 0) + 1
      })
      categories = Object.keys(schoolCounts)
      counts = Object.values(schoolCounts)
    } else {
      // For numerical data
      const values = data.map((student) => student[attribute] || 0)

      if (attribute === "G_Avg") {
        // Create bins for grade averages
        const bins = [0, 5, 10, 15, 20]
        const binCounts = Array(bins.length - 1).fill(0)

        values.forEach((value) => {
          for (let i = 0; i < bins.length - 1; i++) {
            if (value >= bins[i] && value < bins[i + 1]) {
              binCounts[i]++
              break
            }
          }
        })

        categories = bins.slice(0, -1).map((bin, i) => `${bin}-${bins[i + 1]}`)
        counts = binCounts
      } else {
        // Count occurrences of each value
        const valueCounts: Record<number, number> = {}
        values.forEach((value) => {
          valueCounts[value] = (valueCounts[value] || 0) + 1
        })
        categories = Object.keys(valueCounts).map(Number)
        counts = Object.values(valueCounts)
      }
    }

    // Sort categories if they're numbers
    if (attribute !== "School" && attribute !== "G_Avg") {
      const sortedIndices = categories
        .map((_, i) => i)
        .sort((a, b) => (categories[a] as number) - (categories[b] as number))

      categories = sortedIndices.map((i) => categories[i])
      counts = sortedIndices.map((i) => counts[i])
    }

    // Find max count for scaling
    const maxCount = Math.max(...counts)

    // Calculate bar width and spacing
    const barWidth = (width - 2 * padding) / categories.length - 10

    // Draw axes
    ctx.beginPath()
    ctx.strokeStyle = "#888"
    ctx.lineWidth = 1

    // X-axis
    ctx.moveTo(padding, height - padding)
    ctx.lineTo(width - padding, height - padding)

    // Y-axis
    ctx.moveTo(padding, height - padding)
    ctx.lineTo(padding, padding)

    ctx.stroke()

    // Draw axis labels
    ctx.fillStyle = "#888"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"

    // X-axis label
    ctx.fillText(attribute, width / 2, height - 10)

    // Y-axis label
    ctx.save()
    ctx.translate(15, height / 2)
    ctx.rotate(-Math.PI / 2)
    ctx.fillText("Number of Students", 0, 0)
    ctx.restore()

    // Draw Y-axis ticks and values
    ctx.textAlign = "right"
    const yTickCount = 5
    for (let i = 0; i <= yTickCount; i++) {
      const value = (i / yTickCount) * maxCount
      const y = height - padding - (i / yTickCount) * (height - 2 * padding)

      ctx.beginPath()
      ctx.moveTo(padding, y)
      ctx.lineTo(padding - 5, y)
      ctx.stroke()

      ctx.fillText(Math.round(value).toString(), padding - 8, y + 4)
    }

    // Draw bars
    categories.forEach((category, i) => {
      const x = padding + i * ((width - 2 * padding) / categories.length) + 5
      const barHeight = (counts[i] / maxCount) * (height - 2 * padding)
      const y = height - padding - barHeight

      // Draw bar
      ctx.fillStyle = `hsl(${210 + i * 30}, 70%, 60%)`
      ctx.fillRect(x, y, barWidth, barHeight)

      // Draw border
      ctx.strokeStyle = `hsl(${210 + i * 30}, 70%, 50%)`
      ctx.strokeRect(x, y, barWidth, barHeight)

      // Draw category label
      ctx.fillStyle = "#333"
      ctx.textAlign = "center"
      ctx.fillText(category.toString(), x + barWidth / 2, height - padding + 15)

      // Draw count on top of bar
      if (counts[i] > 0) {
        ctx.fillStyle = "#333"
        ctx.fillText(counts[i].toString(), x + barWidth / 2, y - 5)
      }
    })
  }, [attribute, data])

  return (
    <div className="relative h-full w-full">
      <canvas ref={canvasRef} width={800} height={400} className="h-full w-full" />
    </div>
  )
}
