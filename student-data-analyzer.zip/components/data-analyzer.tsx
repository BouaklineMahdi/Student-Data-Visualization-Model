"use client"

import { useEffect, useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DataTable } from "@/components/data-table"
import { DataSorter } from "@/components/data-sorter"
import { CurveFitter } from "@/components/curve-fitter"
import { HistogramVisualizer } from "@/components/histogram-visualizer"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, Loader2 } from "lucide-react"
import { getSampleData } from "@/lib/data-utils"

export interface Student {
  School?: string
  Age?: number
  StudyTime?: number
  Failures?: number
  Health?: number
  Absences?: number
  G1?: number
  G2?: number
  G3?: number
  G_Avg?: number
  [key: string]: any
}

export function DataAnalyzer() {
  const [data, setData] = useState<Student[]>([])
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Automatically load data when component mounts
    const loadData = async () => {
      try {
        setLoading(true)
        // Simulate loading data from a file
        await new Promise((resolve) => setTimeout(resolve, 1000))
        const sampleData = getSampleData()
        console.log("Sample data loaded:", sampleData)
        setData(sampleData)
        setError(null)
      } catch (err) {
        console.error("Error loading data:", err)
        setError("Failed to load data. Please refresh the page.")
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  const handleDataSorted = (sortedData: Student[]) => {
    console.log("Data sorted:", sortedData)
    setData(sortedData)
  }

  return (
    <div className="rounded-lg border bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-950">
      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {loading ? (
        <div className="flex h-64 flex-col items-center justify-center">
          <Loader2 className="mb-4 h-8 w-8 animate-spin text-primary" />
          <p className="text-lg text-gray-500">Loading student data...</p>
        </div>
      ) : (
        <>
          <div className="mb-6">
            <h2 className="mb-2 text-xl font-semibold">Student Data Overview</h2>
            <p className="text-gray-500">
              {data.length} students loaded. Use the tabs below to analyze and visualize the data.
            </p>
          </div>

          <Tabs defaultValue="data">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="data">View Data</TabsTrigger>
              <TabsTrigger value="sort">Sort Data</TabsTrigger>
              <TabsTrigger value="curve">Curve Fit</TabsTrigger>
              <TabsTrigger value="histogram">Histogram</TabsTrigger>
            </TabsList>

            <TabsContent value="data" className="mt-4">
              <DataTable data={data} />
            </TabsContent>

            <TabsContent value="sort" className="mt-4">
              <DataSorter data={data} onDataSorted={handleDataSorted} />
              <div className="mt-6">
                <DataTable data={data} />
              </div>
            </TabsContent>

            <TabsContent value="curve" className="mt-4">
              <CurveFitter data={data} />
            </TabsContent>

            <TabsContent value="histogram" className="mt-4">
              <HistogramVisualizer data={data} />
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}
