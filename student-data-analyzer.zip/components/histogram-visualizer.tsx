"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Student } from "@/components/data-analyzer"
import { BarChart } from "@/components/bar-chart"

interface HistogramVisualizerProps {
  data: Student[]
}

export function HistogramVisualizer({ data }: HistogramVisualizerProps) {
  const [attribute, setAttribute] = useState("School")
  const [isGenerating, setIsGenerating] = useState(false)
  const [showChart, setShowChart] = useState(false)

  const handleGenerateHistogram = async () => {
    setIsGenerating(true)

    try {
      // Simulate histogram generation
      await new Promise((resolve) => setTimeout(resolve, 600))
      setShowChart(true)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Histogram Visualization</CardTitle>
          <CardDescription>Generate a histogram to visualize the distribution of student attributes</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="histAttribute">Attribute</Label>
            <Select value={attribute} onValueChange={setAttribute}>
              <SelectTrigger id="histAttribute">
                <SelectValue placeholder="Select attribute" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Age">Age</SelectItem>
                <SelectItem value="StudyTime">Study Time</SelectItem>
                <SelectItem value="Health">Health</SelectItem>
                <SelectItem value="Failures">Failures</SelectItem>
                <SelectItem value="G_Avg">Grade Average</SelectItem>
                <SelectItem value="School">School</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleGenerateHistogram} className="w-full" disabled={isGenerating}>
            {isGenerating ? "Generating..." : "Generate Histogram"}
          </Button>
        </CardContent>
      </Card>

      {showChart && (
        <Card>
          <CardHeader>
            <CardTitle>Histogram</CardTitle>
            <CardDescription>Distribution of {attribute}</CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <BarChart attribute={attribute} data={data} />
          </CardContent>
        </Card>
      )}
    </div>
  )
}
